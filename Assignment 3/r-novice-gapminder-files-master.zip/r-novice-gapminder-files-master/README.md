R Novice Gapminder Files
====

Some data for use in novice R workshops.




Caveat
----

This dataset is not endorsed by the people at [Gapminder](http://www.gapminder.org).
In particular, we removed relatively incomplete portions of the original data to make it cleaner for our pedagogical purposes.
If you require the unfiltered data you should obtain it from [Gapminder](http://www.gapminder.org/data/).

Also note that this repository is not currently actively maintained.
However, if you would like to improve upon the data herein,
we will view serious pull requests favourably.
